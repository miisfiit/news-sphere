import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - required for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// User preferences table
export const userPreferences = pgTable("user_preferences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  enabledCategories: text("enabled_categories").array().notNull().default(sql`ARRAY['World', 'USA', 'Business', 'Technology', 'Science', 'Sports']::text[]`),
  theme: varchar("theme", { length: 20 }).notNull().default('system'), // light, dark, system, eink
  language: varchar("language", { length: 10 }).notNull().default('en'),
  fontSize: varchar("font_size", { length: 10 }).notNull().default('medium'), // small, medium, large, xlarge
  voiceEnabled: boolean("voice_enabled").notNull().default(false),
  locationConsent: boolean("location_consent").notNull().default(false),
  latitude: text("latitude"),
  longitude: text("longitude"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;

// News articles table (scraped/aggregated news)
export const newsArticles = pgTable("news_articles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description"),
  content: text("content"),
  category: varchar("category", { length: 100 }).notNull(),
  source: varchar("source", { length: 255 }),
  sourceUrl: text("source_url"),
  imageUrls: text("image_urls").array(),
  videoUrl: text("video_url"),
  videoDuration: integer("video_duration"), // in seconds
  publishedAt: timestamp("published_at"),
  language: varchar("language", { length: 10 }).default('en'),
  region: varchar("region", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertNewsArticleSchema = createInsertSchema(newsArticles).omit({
  id: true,
  createdAt: true,
});

export type InsertNewsArticle = z.infer<typeof insertNewsArticleSchema>;
export type NewsArticle = typeof newsArticles.$inferSelect;

// Consent records for privacy compliance
export const consentRecords = pgTable("consent_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }), // Nullable for unauthenticated users
  ipAddress: varchar("ip_address", { length: 45 }),
  consentType: varchar("consent_type", { length: 50 }).notNull(), // 'location', 'cookies', etc.
  consentGiven: boolean("consent_given").notNull(),
  consentText: text("consent_text"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertConsentRecordSchema = createInsertSchema(consentRecords).omit({
  id: true,
  createdAt: true,
}).extend({
  userId: z.string().nullable().optional(), // Make userId optional and nullable
});

export type InsertConsentRecord = z.infer<typeof insertConsentRecordSchema>;
export type ConsentRecord = typeof consentRecords.$inferSelect;

// Available categories list (for reference)
export const CATEGORIES = [
  'World', 'USA', 'Business', 'Technology', 'Science', 'Sports', 'Gaming', 'Today in History',
  'Africa', 'AI', 'Apple', 'Argentina', 'Australia', 'Austria', 'Belgium', 'Brazil', 'Canada',
  'Catholic', 'China', 'Costa Rica', 'Croatia', 'Cryptocurrency', 'Cybersecurity', 'Czech Republic',
  'Economy', 'Estonia', 'Europe', 'Finland', 'Formula 1', 'France', 'Germany', 'Germany | Hesse',
  'Greece', 'Hungary', 'India', 'Iran', 'Ireland', 'Israel', 'Italy', 'Japan', 'Linux & OSS',
  'Lithuania', 'Mexico', 'Middle East', 'Netherlands', 'New Zealand', 'NHL', 'Norway', 'Pakistan',
  'Palestine', 'Philippines', 'Podcasting', 'Poland', 'Portugal', 'Privacy', 'Romania', 'Russia',
  'Serbia', 'Slovakia', 'Slovenia', 'South Korea', 'Spain', 'Sweden', 'Switzerland', 'Taiwan',
  'Thailand', 'Turkey', 'UK', 'Ukraine', 'USA | Bay Area', 'USA | Chicago', 'USA | Colorado',
  'USA | Michigan', 'USA | New York City', 'USA | Utah', 'USA | Vermont', 'USA | Virginia'
] as const;

export type Category = typeof CATEGORIES[number];

// Language options
export const LANGUAGES = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
  { code: 'de', name: 'Deutsch' },
  { code: 'it', name: 'Italiano' },
  { code: 'pt', name: 'Português' },
  { code: 'zh', name: '中文' },
  { code: 'ja', name: '日本語' },
  { code: 'ko', name: '한국어' },
  { code: 'ar', name: 'العربية' },
  { code: 'ru', name: 'Русский' },
  { code: 'hi', name: 'हिन्दी' },
] as const;
