# Design Guidelines: Minimalist News Reader App

## Design Approach

**Selected Approach:** Reference-Based (Minimalist Reading Apps)

**Primary References:** Pocket, Instapaper, Feedly, Apple News
- Focus on reading comfort and content clarity
- Minimal UI chrome to maximize content space
- Clean typography hierarchy for extended reading sessions

**Design Philosophy:** "Content-First Minimalism" - Every pixel serves the reading experience. Interface elements appear only when needed, fade gracefully when not.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Text Primary: 0 0% 10%
- Text Secondary: 0 0% 40%
- Border: 0 0% 90%
- Accent: 210 100% 50% (minimal use, links and active states only)

**Dark Mode:**
- Background: 0 0% 8%
- Surface: 0 0% 12%
- Text Primary: 0 0% 95%
- Text Secondary: 0 0% 70%
- Border: 0 0% 20%
- Accent: 210 100% 60%

**E-ink Mode:**
- Background: 0 0% 100%
- Surface: 0 0% 100%
- Text: 0 0% 0%
- Borders: 0 0% 80%
- No shadows, no gradients, maximum contrast
- Single-weight typography (no bold/light variations)

**System Mode:** Auto-detects and applies Light or Dark based on OS preference

### B. Typography

**Font Families:**
- Headlines: "Inter" (500-600 weight)
- Body Text: "Lora" or "Merriweather" (serif for reading comfort) at 400 weight
- UI Elements: "Inter" (400-500 weight)

**Scale:**
- Article Headline: text-3xl to text-4xl (30-36px)
- Article Body: text-lg (18px) - optimized for reading
- Section Headers: text-xl (20px)
- UI Labels: text-sm to text-base (14-16px)
- Metadata/Timestamps: text-xs to text-sm (12-14px)

**Line Height:** Generous spacing - leading-relaxed (1.625) for body text, leading-normal for headlines

### C. Layout System

**Spacing Units:** Use Tailwind units of 2, 4, 6, 8, 12, 16 for consistent rhythm
- Micro spacing (within components): p-2, gap-2
- Component padding: p-4 to p-6
- Section spacing: py-8 to py-12
- Page margins: px-4 (mobile), px-8 (tablet), px-16 (desktop)

**Reading Width:** max-w-3xl (768px) for article content - optimal reading line length
**Settings/UI Width:** max-w-md for forms and control panels
**Full-width:** Category grids and news feed listings

### D. Component Library

**Navigation Header:**
- Minimal fixed header: Logo/brand (left), theme switcher icon, settings icon, account button (right)
- Height: h-16 with subtle border-bottom
- Semi-transparent background with backdrop-blur on scroll
- Mobile: Hamburger menu collapses all settings into drawer

**Category Management:**
- Toggle switches matching screenshot reference
- Grid layout: grid-cols-2 on mobile, grid-cols-3 on tablet, grid-cols-4 on desktop
- Each category card: Icon (subtle), label, toggle switch (right-aligned)
- Active state: Slight background tint, not jarring color change
- Categories: Business, Entertainment, Health, Politics, Science, Sports, Technology, World News, Local News

**News Article Cards:**
- Clean card design with subtle border or minimal shadow (except e-ink mode)
- Layout: Image(s) → Headline → Source/Time metadata → Brief excerpt → Video (if present)
- Image aspect ratio: 16:9, max 2 images in horizontal scroll/grid
- Video: Small thumbnail with play icon, positioned last
- Spacing: gap-4 between elements, p-4 card padding
- Hover: Subtle lift effect (not in e-ink mode)

**Settings Panel:**
- Organized sections with clear headers
- Theme Switcher: Four-option segmented control (Light, Dark, System, E-ink)
- Language Selector: Dropdown with flag icons
- Font Size: Slider with live preview, range from 14px to 24px, steps of 2px
- Voice Control: Toggle with permission prompt explanation
- Location Services: Toggle with privacy notice, "Learn More" link to privacy policy
- Export Settings: Prominent button with download icon

**Authentication:**
- Minimal login modal/slide-in panel
- Options: Continue with Google, GitHub, Email/Password
- Privacy statement: "We only store your preferences. No tracking."
- Optional: "Continue without account" to save locally

**Accessibility Panel:**
- Font Size Control: Large touch-friendly slider
- Voice Control: Microphone icon button (always visible when enabled)
- High Contrast Mode: Toggle (separate from themes)
- Screen Reader Optimization: Proper ARIA labels throughout

**Article View:**
- Immersive reading mode: Hides navigation, shows only content and minimal controls
- Progress indicator: Subtle scroll progress bar at top
- Action buttons (floating, bottom-right): Bookmark, Share, Font Size, Text-to-Speech
- Image modal: Click to expand images full-screen with minimal chrome

### E. Animations & Interactions

**Minimal Motion Approach:**
- Theme transitions: Smooth 200ms color fade
- Toggle switches: Quick snap animation (150ms)
- Card hover: Subtle translate-y lift (100ms)
- Modal/drawer: Slide-in/fade-in (250ms ease-out)
- Voice control: Pulsing microphone indicator when listening
- No scroll-triggered animations
- Respect prefers-reduced-motion

## Special Considerations

**Privacy-First Messaging:**
- Prominent privacy policy link in footer
- Clear consent banners for location services
- "Why we need this" explanations for permissions
- Data export always accessible

**Multi-Language Support:**
- Language selector in settings with native language names
- RTL layout support for Arabic, Hebrew
- Font stack adjusted per language (e.g., Noto Sans for Asian languages)
- Date/time formatting localized

**E-ink Optimization:**
- Eliminate all shadows and gradients
- Maximum contrast ratios (21:1)
- No hover states (assume touch/click only)
- Larger touch targets (min 44x44px)
- Simplified iconography with solid fills

**Responsive Breakpoints:**
- Mobile: < 640px (single column, stacked layout)
- Tablet: 640-1024px (two-column grids, side navigation option)
- Desktop: > 1024px (three-column option for feed, comfortable reading width)

## Images

**Hero Section:** Not applicable - functional app prioritizes immediate access to content

**Article Images:**
- Placement: Top of article card, before headline
- Maximum 2 images per article, horizontal scroll or stacked
- Aspect ratio: 16:9, responsive sizing
- Alt text required for accessibility
- Lazy loading for performance
- Placeholder: Light gray box with icon during load

**Category Icons:**
- Simple line icons or filled icons matching theme
- Sources: Heroicons or Lucide icons
- Size: 20-24px
- Consistent style across all categories

**Empty States:**
- Centered illustration + message when no articles in category
- "No saved articles yet" with bookmark icon
- "Enable location for local news" with map pin icon

This minimalist, accessibility-focused design ensures optimal reading experience across all devices while respecting user privacy and providing powerful customization options.