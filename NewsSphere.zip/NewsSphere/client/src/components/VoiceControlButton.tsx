import { Mic, MicOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useVoiceControl } from '@/hooks/useVoiceControl';
import { useSettings } from '@/contexts/SettingsContext';
import { Badge } from '@/components/ui/badge';

export function VoiceControlButton({ onCommand }: { onCommand?: (command: string) => void }) {
  const { settings } = useSettings();
  const { isSupported, isListening, startListening, stopListening } = useVoiceControl({ onCommand });

  if (!settings.voiceEnabled || !isSupported) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      {isListening && (
        <Badge variant="default" className="animate-pulse">
          Listening...
        </Badge>
      )}
      <Button
        size="icon"
        variant={isListening ? "default" : "secondary"}
        onClick={isListening ? stopListening : startListening}
        data-testid="button-voice-control"
        className="h-14 w-14 rounded-full shadow-lg hover-elevate active-elevate-2"
      >
        {isListening ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
      </Button>
    </div>
  );
}
