import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Globe, Type, Mic, Info } from 'lucide-react';
import { useSettings, type FontSize, type Language } from '@/contexts/SettingsContext';
import { useUserPreferences } from '@/hooks/useUserPreferences';
import { useConsentTracking } from '@/hooks/useConsentTracking';
import { LANGUAGES } from '@shared/schema';
import { useState } from 'react';

const fontSizeLabels: Record<FontSize, string> = {
  small: 'Small (14px)',
  medium: 'Medium (18px)',
  large: 'Large (20px)',
  xlarge: 'Extra Large (24px)',
};

const fontSizeValues: FontSize[] = ['small', 'medium', 'large', 'xlarge'];

export function SettingsPanel() {
  const { settings, updateSettings } = useSettings();
  const { syncToServer } = useUserPreferences();
  const { recordConsent } = useConsentTracking();
  const [locationLoading, setLocationLoading] = useState(false);

  const handleLanguageChange = (language: Language) => {
    updateSettings({ language });
    syncToServer({ language });
  };

  const handleFontSizeChange = (fontSize: FontSize) => {
    updateSettings({ fontSize });
    syncToServer({ fontSize });
  };

  const handleVoiceToggle = (enabled: boolean) => {
    updateSettings({ voiceEnabled: enabled });
    syncToServer({ voiceEnabled: enabled });
  };

  const handleLocationToggle = (enabled: boolean) => {
    if (enabled) {
      setLocationLoading(true);
      if ('geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            updateSettings({ locationConsent: true });
            syncToServer({ 
              locationConsent: true,
              latitude: position.coords.latitude.toString(),
              longitude: position.coords.longitude.toString(),
            });
            recordConsent(
              'location',
              true,
              `User granted location access. Coordinates: ${position.coords.latitude}, ${position.coords.longitude}`
            );
            setLocationLoading(false);
          },
          (error) => {
            console.error('Location error:', error);
            setLocationLoading(false);
          }
        );
      } else {
        setLocationLoading(false);
      }
    } else {
      updateSettings({ locationConsent: false });
      syncToServer({ locationConsent: false, latitude: null, longitude: null });
      recordConsent('location', false, 'User revoked location access');
    }
  };

  const fontSizeIndex = fontSizeValues.indexOf(settings.fontSize);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Language
          </CardTitle>
          <CardDescription>
            Choose your preferred language for news content
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select
            value={settings.language}
            onValueChange={(value) => handleLanguageChange(value as Language)}
          >
            <SelectTrigger data-testid="select-language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((lang) => (
                <SelectItem 
                  key={lang.code} 
                  value={lang.code}
                  data-testid={`option-language-${lang.code}`}
                >
                  {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Type className="h-5 w-5" />
            Font Size
          </CardTitle>
          <CardDescription>
            Adjust the reading font size for better readability
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label data-testid="text-font-size-label">
                {fontSizeLabels[settings.fontSize]}
              </Label>
            </div>
            <Slider
              value={[fontSizeIndex]}
              onValueChange={(value) => handleFontSizeChange(fontSizeValues[value[0]])}
              max={3}
              step={1}
              data-testid="slider-font-size"
            />
          </div>
          <div 
            className="font-serif p-4 border rounded-md bg-card"
            style={{ fontSize: 'var(--reading-font-size, 18px)' }}
          >
            <p className="leading-relaxed">
              Sample text: The quick brown fox jumps over the lazy dog. This is how your articles will appear.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            Voice Control
          </CardTitle>
          <CardDescription>
            Enable hands-free navigation and text-to-speech
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="voice-enabled" className="flex-1">
              Enable voice control
            </Label>
            <Switch
              id="voice-enabled"
              checked={settings.voiceEnabled}
              onCheckedChange={handleVoiceToggle}
              data-testid="switch-voice-control"
            />
          </div>
          {settings.voiceEnabled && (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Use the microphone button in the bottom-right corner to give voice commands, or click "Read Aloud" on any article.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Location Services
          </CardTitle>
          <CardDescription>
            Enable location access for personalized local news
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="location-consent" className="flex-1">
              Allow location access
            </Label>
            <Switch
              id="location-consent"
              checked={settings.locationConsent}
              onCheckedChange={handleLocationToggle}
              disabled={locationLoading}
              data-testid="switch-location-consent"
            />
          </div>
          <Alert variant="default" className="border-primary/20 bg-primary/5">
            <Info className="h-4 w-4" />
            <AlertDescription className="text-xs">
              <strong>Privacy Notice:</strong> By enabling location services, you consent to the collection of your geographic coordinates for the purpose of providing local news. This data is stored in compliance with Virginia and US federal privacy regulations. You can revoke consent at any time.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}
