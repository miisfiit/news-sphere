import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Play, Volume2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { NewsArticle } from '@shared/schema';
import { useVoiceControl } from '@/hooks/useVoiceControl';
import { useSettings } from '@/contexts/SettingsContext';

interface ArticleCardProps {
  article: NewsArticle;
}

export function ArticleCard({ article }: ArticleCardProps) {
  const { settings } = useSettings();
  const { speak, isSpeaking } = useVoiceControl();

  const handleReadAloud = () => {
    const text = `${article.title}. ${article.description || article.content || ''}`;
    speak(text);
  };

  return (
    <Card className="overflow-hidden hover-elevate transition-all" data-testid={`card-article-${article.id}`}>
      {article.imageUrls && article.imageUrls.length > 0 && (
        <div className="flex gap-2 overflow-x-auto p-4 pb-0">
          {article.imageUrls.slice(0, 2).map((url, index) => (
            <img
              key={index}
              src={url}
              alt={`${article.title} - Image ${index + 1}`}
              className="h-48 w-full sm:w-80 object-cover rounded-md flex-shrink-0"
              data-testid={`img-article-${article.id}-${index}`}
            />
          ))}
        </div>
      )}

      <CardHeader className="space-y-3">
        <div className="flex items-start justify-between gap-2 flex-wrap">
          <Badge variant="secondary" data-testid={`badge-category-${article.category}`}>
            {article.category}
          </Badge>
          {settings.voiceEnabled && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReadAloud}
              disabled={isSpeaking}
              data-testid={`button-read-aloud-${article.id}`}
              className="gap-2 h-8"
            >
              <Volume2 className="h-4 w-4" />
              Read Aloud
            </Button>
          )}
        </div>
        
        <h2 
          className="font-serif text-2xl font-semibold leading-tight tracking-tight"
          style={{ fontSize: 'var(--reading-font-size, 18px)' }}
          data-testid={`text-article-title-${article.id}`}
        >
          {article.title}
        </h2>

        <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
          {article.source && (
            <>
              <span data-testid={`text-article-source-${article.id}`}>{article.source}</span>
              <span>•</span>
            </>
          )}
          {article.publishedAt && (
            <span data-testid={`text-article-time-${article.id}`}>
              {formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })}
            </span>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {article.description && (
          <p 
            className="text-foreground leading-relaxed font-serif"
            style={{ fontSize: 'var(--reading-font-size, 18px)' }}
            data-testid={`text-article-description-${article.id}`}
          >
            {article.description}
          </p>
        )}

        {article.videoUrl && (
          <div className="relative rounded-md overflow-hidden bg-muted">
            <div className="aspect-video flex items-center justify-center">
              <Button
                variant="secondary"
                size="lg"
                className="gap-2"
                data-testid={`button-play-video-${article.id}`}
              >
                <Play className="h-5 w-5" />
                Play Video
                {article.videoDuration && (
                  <span className="text-xs">({article.videoDuration}s)</span>
                )}
              </Button>
            </div>
          </div>
        )}

        {article.sourceUrl && (
          <Button
            variant="outline"
            size="sm"
            asChild
            className="w-full sm:w-auto"
            data-testid={`link-article-source-${article.id}`}
          >
            <a href={article.sourceUrl} target="_blank" rel="noopener noreferrer">
              Read Full Article
            </a>
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
