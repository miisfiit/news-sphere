import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useSettings } from '@/contexts/SettingsContext';
import { useConsentTracking } from '@/hooks/useConsentTracking';
import { Link } from 'wouter';

export function CookieConsent() {
  const { settings, updateSettings } = useSettings();
  const { recordConsent } = useConsentTracking();
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!settings.cookieConsent) {
      const timer = setTimeout(() => setShow(true), 1000);
      return () => clearTimeout(timer);
    }
  }, [settings.cookieConsent]);

  if (!show || settings.cookieConsent) return null;

  const handleAccept = () => {
    updateSettings({ cookieConsent: true });
    recordConsent('cookies', true, 'User accepted essential cookies for authentication and session management');
    setShow(false);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4">
      <Card className="mx-auto max-w-2xl p-6 shadow-xl">
        <div className="flex flex-col gap-4">
          <div className="space-y-2">
            <h3 className="font-semibold text-lg" data-testid="text-cookie-title">
              Privacy & Cookies
            </h3>
            <p className="text-sm text-muted-foreground" data-testid="text-cookie-description">
              We use essential cookies to provide core functionality. We do not track you or collect personal data unless you explicitly opt-in to location services for local news.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 justify-end">
            <Link href="/privacy">
              <Button 
                variant="ghost" 
                size="sm"
                data-testid="link-privacy-policy"
              >
                Privacy Policy
              </Button>
            </Link>
            <Button 
              onClick={handleAccept}
              size="sm"
              data-testid="button-accept-cookies"
            >
              Accept & Continue
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
