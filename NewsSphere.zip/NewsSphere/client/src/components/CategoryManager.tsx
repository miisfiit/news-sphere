import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { CATEGORIES, type Category } from '@shared/schema';
import { useSettings } from '@/contexts/SettingsContext';
import { useUserPreferences } from '@/hooks/useUserPreferences';
import { 
  Globe, Flag, Briefcase, Cpu, FlaskConical, Trophy, Gamepad2, 
  Calendar, MapPin, Brain, Apple, DollarSign, Shield, Bitcoin,
  Database, Newspaper, Podcast, Lock
} from 'lucide-react';

const categoryIcons: Record<string, any> = {
  'World': Globe,
  'USA': Flag,
  'Business': Briefcase,
  'Technology': Cpu,
  'Science': FlaskConical,
  'Sports': Trophy,
  'Gaming': Gamepad2,
  'Today in History': Calendar,
  'AI': Brain,
  'Apple': Apple,
  'Economy': DollarSign,
  'Cybersecurity': Shield,
  'Cryptocurrency': Bitcoin,
  'Linux & OSS': Database,
  'NHL': Trophy,
  'Formula 1': Trophy,
  'Podcasting': Podcast,
  'Privacy': Lock,
};

const getIconForCategory = (category: Category) => {
  return categoryIcons[category] || Newspaper;
};

export function CategoryManager() {
  const { settings, toggleCategory } = useSettings();
  const { syncToServer } = useUserPreferences();

  const handleToggleCategory = (category: Category) => {
    toggleCategory(category);
    const newCategories = settings.enabledCategories.includes(category)
      ? settings.enabledCategories.filter(c => c !== category)
      : [...settings.enabledCategories, category];
    syncToServer({ enabledCategories: newCategories });
  };

  const enabledCount = settings.enabledCategories.length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between flex-wrap gap-2">
          <span>Manage Categories</span>
          <Badge variant="secondary" data-testid="text-enabled-count">
            {enabledCount} enabled
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {CATEGORIES.map((category) => {
            const isEnabled = settings.enabledCategories.includes(category);
            const Icon = getIconForCategory(category);
            
            return (
              <div
                key={category}
                className={`flex items-center justify-between gap-3 p-3 rounded-md border transition-colors hover-elevate ${
                  isEnabled ? 'bg-accent/50' : ''
                }`}
                data-testid={`category-item-${category}`}
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <Icon className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                  <span className="text-sm font-medium truncate">{category}</span>
                </div>
                <Switch
                  checked={isEnabled}
                  onCheckedChange={() => handleToggleCategory(category)}
                  data-testid={`switch-category-${category}`}
                />
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
