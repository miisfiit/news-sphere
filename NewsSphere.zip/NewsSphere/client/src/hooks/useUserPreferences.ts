import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from './useAuth';
import { useSettings } from '@/contexts/SettingsContext';
import { useEffect } from 'react';
import type { UserPreferences, InsertUserPreferences } from '@shared/schema';
import { useToast } from './use-toast';

export function useUserPreferences() {
  const { isAuthenticated, user } = useAuth();
  const { settings, updateSettings } = useSettings();
  const { toast } = useToast();

  // Fetch preferences from server
  const { data: serverPrefs, isLoading } = useQuery<UserPreferences>({
    queryKey: ['/api/preferences'],
    enabled: isAuthenticated,
    retry: false,
  });

  // Sync server preferences to local settings when fetched
  useEffect(() => {
    if (serverPrefs && isAuthenticated) {
      updateSettings({
        enabledCategories: serverPrefs.enabledCategories as any,
        language: serverPrefs.language as any,
        fontSize: serverPrefs.fontSize as any,
        voiceEnabled: serverPrefs.voiceEnabled,
        locationConsent: serverPrefs.locationConsent,
      });
    }
  }, [serverPrefs, isAuthenticated]);

  // Mutation to update preferences on server
  const updatePrefsMutation = useMutation({
    mutationFn: async (updates: Partial<InsertUserPreferences>) => {
      return await apiRequest('PUT', '/api/preferences', updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/preferences'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: 'Failed to save preferences to server',
        variant: 'destructive',
      });
      console.error('Failed to update preferences:', error);
    },
  });

  // Sync local settings changes to server when authenticated
  const syncToServer = (updates: Partial<InsertUserPreferences>) => {
    if (isAuthenticated) {
      updatePrefsMutation.mutate(updates);
    }
  };

  return {
    serverPrefs,
    isLoading,
    syncToServer,
    isSyncing: updatePrefsMutation.isPending,
  };
}
