import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import type { InsertConsentRecord } from '@shared/schema';

export function useConsentTracking() {
  const recordConsentMutation = useMutation({
    mutationFn: async (consent: Omit<InsertConsentRecord, 'userId' | 'ipAddress'>) => {
      return await apiRequest('POST', '/api/consent', consent);
    },
  });

  const recordConsent = (consentType: string, consentGiven: boolean, consentText?: string) => {
    // Record consent for both authenticated and unauthenticated users
    recordConsentMutation.mutate({
      consentType,
      consentGiven,
      consentText,
    });
  };

  return {
    recordConsent,
    isRecording: recordConsentMutation.isPending,
  };
}
