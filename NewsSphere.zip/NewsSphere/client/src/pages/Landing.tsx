import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Shield, Palette, Type, Mic, Globe, Download, 
  Newspaper, Lock, Eye, Settings
} from 'lucide-react';
import { Header } from '@/components/Header';
import { CookieConsent } from '@/components/CookieConsent';
import { Link } from 'wouter';

export default function Landing() {
  const handleLogin = () => {
    window.location.href = '/api/login';
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <section className="container px-4 py-16 md:py-24">
          <div className="mx-auto max-w-3xl text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-serif tracking-tight">
                Read News Your Way
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                A privacy-focused minimalist news reader with customizable categories, themes, and accessibility features. No tracking, no clutter, just news.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button 
                size="lg" 
                onClick={handleLogin}
                data-testid="button-get-started"
                className="text-lg px-8"
              >
                Get Started Free
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                asChild
                data-testid="link-learn-more"
                className="text-lg px-8"
              >
                <Link href="/privacy">Learn About Privacy</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="bg-muted/30 py-16 md:py-24">
          <div className="container px-4">
            <div className="mx-auto max-w-5xl">
              <h2 className="text-3xl font-bold text-center mb-12 font-serif">
                Features Built for You
              </h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Shield className="h-6 w-6 text-primary" />
                      Privacy First
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      No tracking, no analytics, no data collection unless you explicitly opt-in for location-based local news.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Palette className="h-6 w-6 text-primary" />
                      4 Theme Options
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Light, Dark, System, and E-ink display modes. Perfect for any device or reading condition.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Newspaper className="h-6 w-6 text-primary" />
                      60+ Categories
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      From World and Tech to local regions and specialized topics. Enable only what you want to read.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Type className="h-6 w-6 text-primary" />
                      Adjustable Font Size
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Choose from 4 reading sizes for optimal comfort. Your eyes will thank you.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Mic className="h-6 w-6 text-primary" />
                      Voice Control
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Hands-free navigation and text-to-speech. Listen to articles while multitasking.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Globe className="h-6 w-6 text-primary" />
                      Multi-Language
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Read news in 12 different languages. Stay informed in your preferred language.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Download className="h-6 w-6 text-primary" />
                      Export Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Download your preferences as a backup. No account required to save settings locally.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Eye className="h-6 w-6 text-primary" />
                      Minimalist Design
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Clean, distraction-free reading experience. Content first, always.
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <Settings className="h-6 w-6 text-primary" />
                      Full Control
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Every feature is optional. Customize your experience exactly how you want it.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        <section className="container px-4 py-16 md:py-24">
          <div className="mx-auto max-w-3xl text-center space-y-8">
            <h2 className="text-3xl font-bold font-serif">
              Your Privacy Matters
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We believe in transparent, user-controlled privacy. Your data belongs to you. 
              We only collect what's necessary for the features you choose to enable.
            </p>
            <div className="flex items-center justify-center gap-4 pt-4">
              <Lock className="h-8 w-8 text-primary" />
              <div className="text-left">
                <p className="font-semibold">Compliant with:</p>
                <p className="text-sm text-muted-foreground">Virginia Privacy Laws & US Federal Regulations</p>
              </div>
            </div>
            <Button 
              size="lg"
              onClick={handleLogin}
              data-testid="button-cta-bottom"
              className="text-lg px-8"
            >
              Start Reading Now
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2025 MinNews. Privacy-focused news reading.</p>
            <Link href="/privacy">
              <Button variant="ghost" size="sm" data-testid="link-footer-privacy">
                Privacy Policy
              </Button>
            </Link>
          </div>
        </div>
      </footer>

      <CookieConsent />
    </div>
  );
}
