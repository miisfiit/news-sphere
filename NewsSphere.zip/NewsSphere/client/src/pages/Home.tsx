import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/Header';
import { ArticleCard } from '@/components/ArticleCard';
import { CategoryManager } from '@/components/CategoryManager';
import { SettingsPanel } from '@/components/SettingsPanel';
import { VoiceControlButton } from '@/components/VoiceControlButton';
import { CookieConsent } from '@/components/CookieConsent';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';
import { useSettings } from '@/contexts/SettingsContext';
import type { NewsArticle } from '@shared/schema';

export default function Home() {
  const { settings } = useSettings();
  const [activeTab, setActiveTab] = useState('news');

  const { data: articles, isLoading, error, refetch } = useQuery<NewsArticle[]>({
    queryKey: ['/api/news', settings.enabledCategories, settings.language],
    enabled: activeTab === 'news',
  });

  const handleVoiceCommand = (command: string) => {
    if (command.includes('categories') || command.includes('settings')) {
      setActiveTab('categories');
    } else if (command.includes('preferences') || command.includes('options')) {
      setActiveTab('settings');
    } else if (command.includes('news') || command.includes('articles')) {
      setActiveTab('news');
    } else if (command.includes('refresh') || command.includes('reload')) {
      refetch();
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1 container px-4 py-8 max-w-6xl mx-auto">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-8">
            <TabsTrigger value="news" data-testid="tab-news">
              News Feed
            </TabsTrigger>
            <TabsTrigger value="categories" data-testid="tab-categories">
              Categories
            </TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="news" className="space-y-6">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="text-center py-12 space-y-4">
                <p className="text-muted-foreground">
                  Failed to load articles. Please try again.
                </p>
                <Button onClick={() => refetch()} data-testid="button-retry">
                  Retry
                </Button>
              </div>
            ) : articles && articles.length > 0 ? (
              <div className="space-y-6">
                {articles.map((article) => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12 space-y-4">
                <p className="text-muted-foreground" data-testid="text-no-articles">
                  No articles found for your selected categories.
                </p>
                <Button 
                  onClick={() => setActiveTab('categories')}
                  data-testid="button-manage-categories"
                >
                  Manage Categories
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="categories">
            <CategoryManager />
          </TabsContent>

          <TabsContent value="settings">
            <SettingsPanel />
          </TabsContent>
        </Tabs>
      </main>

      <VoiceControlButton onCommand={handleVoiceCommand} />
      <CookieConsent />
    </div>
  );
}
