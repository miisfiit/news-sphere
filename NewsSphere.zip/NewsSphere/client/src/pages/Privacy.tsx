import { Header } from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { ArrowLeft } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container px-4 py-8 max-w-4xl mx-auto">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" className="gap-2" data-testid="link-back-home">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="space-y-8">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold font-serif">Privacy Policy</h1>
            <p className="text-muted-foreground">Last updated: October 18, 2025</p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Our Privacy Commitment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                MinNews is built with privacy as a fundamental principle. We believe your reading habits and preferences are personal, and we're committed to protecting them.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Information We Collect</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Essential Information (Always Collected)</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Account information when you sign up (email, name, profile picture)</li>
                  <li>Your category preferences and theme settings</li>
                  <li>Essential cookies for authentication and session management</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">Optional Information (Only With Your Consent)</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li><strong>Location Data:</strong> Geographic coordinates (latitude/longitude) when you enable local news</li>
                  <li><strong>Voice Data:</strong> Temporary voice commands processed locally in your browser (not stored or transmitted)</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">What We Don't Collect</h3>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Browsing history or reading patterns</li>
                  <li>Analytics or tracking cookies</li>
                  <li>Third-party advertising data</li>
                  <li>Device fingerprinting information</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>How We Use Your Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <ul className="list-disc pl-6 space-y-2">
                <li>
                  <strong>Account Information:</strong> To provide authentication and save your preferences across devices
                </li>
                <li>
                  <strong>Category Preferences:</strong> To filter and personalize your news feed
                </li>
                <li>
                  <strong>Location Data:</strong> To fetch relevant local news for your area (only when enabled)
                </li>
                <li>
                  <strong>Settings:</strong> To customize your reading experience (theme, font size, language)
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Storage & Security</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Your data is stored securely in encrypted databases. We implement industry-standard security measures including:
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li>SSL/TLS encryption for all data transmission</li>
                <li>Secure password hashing (we never store plain-text passwords)</li>
                <li>Regular security audits and updates</li>
                <li>Limited employee access to user data</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Rights (Virginia & US Federal Compliance)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>Under Virginia Consumer Data Protection Act (VCDPA) and federal regulations, you have the right to:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Access:</strong> Request a copy of all data we have about you</li>
                <li><strong>Correction:</strong> Request corrections to inaccurate information</li>
                <li><strong>Deletion:</strong> Request deletion of your account and all associated data</li>
                <li><strong>Portability:</strong> Export your settings and preferences at any time</li>
                <li><strong>Opt-Out:</strong> Revoke consent for location services anytime</li>
                <li><strong>No Sale:</strong> We never sell your personal information to third parties</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Location Data Consent</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                When you enable location services for local news:
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li>We collect your geographic coordinates (latitude/longitude)</li>
                <li>This data is used solely to provide relevant local news</li>
                <li>We maintain a timestamped consent record as required by Virginia law</li>
                <li>You can revoke consent at any time in Settings</li>
                <li>Upon revocation, we stop using location data immediately</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Third-Party Services</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                We use minimal third-party services:
              </p>
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Authentication Provider:</strong> Secure OAuth for login (Google, GitHub, etc.)</li>
                <li><strong>News Sources:</strong> We aggregate news from public RSS feeds and APIs</li>
              </ul>
              <p className="mt-4">
                We do not use third-party analytics, advertising networks, or social media trackers.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Retention</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <ul className="list-disc pl-6 space-y-1">
                <li><strong>Account Data:</strong> Retained until you delete your account</li>
                <li><strong>Settings & Preferences:</strong> Retained as long as your account is active</li>
                <li><strong>Consent Records:</strong> Retained for 3 years as required by law</li>
                <li><strong>Deleted Data:</strong> Permanently removed within 30 days of deletion request</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Children's Privacy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                MinNews is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Changes to This Policy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                We may update this privacy policy from time to time. We will notify you of any changes by updating the "Last updated" date at the top of this policy.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                If you have questions about this privacy policy or your data, you can contact us at:
              </p>
              <p className="font-mono text-sm bg-muted p-3 rounded-md">
                privacy@minnews.example.com
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t py-8">
        <div className="container px-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>© 2025 MinNews. Privacy-focused news reading.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
