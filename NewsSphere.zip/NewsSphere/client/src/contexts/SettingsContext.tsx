import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { CATEGORIES, type Category } from '@shared/schema';
import { useTheme } from './ThemeContext';

export type FontSize = 'small' | 'medium' | 'large' | 'xlarge';
export type Language = 'en' | 'es' | 'fr' | 'de' | 'it' | 'pt' | 'zh' | 'ja' | 'ko' | 'ar' | 'ru' | 'hi';

export interface Settings {
  enabledCategories: Category[];
  language: Language;
  fontSize: FontSize;
  voiceEnabled: boolean;
  locationConsent: boolean;
  cookieConsent: boolean;
}

interface SettingsContextType {
  settings: Settings;
  updateSettings: (updates: Partial<Settings>) => void;
  toggleCategory: (category: Category) => void;
  exportSettings: () => void;
  importSettings: (data: Partial<Settings>) => void;
}

const defaultSettings: Settings = {
  enabledCategories: ['World', 'USA', 'Business', 'Technology', 'Science', 'Sports'],
  language: 'en',
  fontSize: 'medium',
  voiceEnabled: false,
  locationConsent: false,
  cookieConsent: false,
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const { theme } = useTheme();
  const [settings, setSettings] = useState<Settings>(() => {
    const stored = localStorage.getItem('newsReaderSettings');
    if (stored) {
      try {
        return { ...defaultSettings, ...JSON.parse(stored) };
      } catch {
        return defaultSettings;
      }
    }
    return defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem('newsReaderSettings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    const fontSizeMap = {
      small: '14px',
      medium: '18px',
      large: '20px',
      xlarge: '24px',
    };
    document.documentElement.style.setProperty('--reading-font-size', fontSizeMap[settings.fontSize]);
  }, [settings.fontSize]);

  const updateSettings = (updates: Partial<Settings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const toggleCategory = (category: Category) => {
    setSettings(prev => {
      const enabled = prev.enabledCategories.includes(category);
      return {
        ...prev,
        enabledCategories: enabled
          ? prev.enabledCategories.filter(c => c !== category)
          : [...prev.enabledCategories, category]
      };
    });
  };

  const exportSettings = () => {
    const data = {
      settings,
      theme,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `news-reader-settings-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const importSettings = (data: Partial<Settings>) => {
    setSettings(prev => ({ ...prev, ...data }));
  };

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, toggleCategory, exportSettings, importSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
