import {
  users,
  userPreferences,
  newsArticles,
  consentRecords,
  type User,
  type UpsertUser,
  type UserPreferences,
  type InsertUserPreferences,
  type NewsArticle,
  type InsertNewsArticle,
  type ConsentRecord,
  type InsertConsentRecord,
  type Category,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, inArray, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // User preferences operations
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  createUserPreferences(prefs: InsertUserPreferences): Promise<UserPreferences>;
  updateUserPreferences(userId: string, updates: Partial<InsertUserPreferences>): Promise<UserPreferences>;

  // News articles operations
  getNewsArticles(categories: Category[], language: string, limit?: number): Promise<NewsArticle[]>;
  createNewsArticle(article: InsertNewsArticle): Promise<NewsArticle>;

  // Consent records operations
  createConsentRecord(record: InsertConsentRecord): Promise<ConsentRecord>;
  getUserConsents(userId: string): Promise<ConsentRecord[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // User preferences operations
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [prefs] = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId));
    return prefs;
  }

  async createUserPreferences(prefs: InsertUserPreferences): Promise<UserPreferences> {
    const [created] = await db
      .insert(userPreferences)
      .values(prefs)
      .returning();
    return created;
  }

  async updateUserPreferences(userId: string, updates: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    const [updated] = await db
      .update(userPreferences)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(userPreferences.userId, userId))
      .returning();
    return updated;
  }

  // News articles operations
  async getNewsArticles(categories: Category[], language: string, limit: number = 50): Promise<NewsArticle[]> {
    let query = db
      .select()
      .from(newsArticles)
      .where(
        and(
          inArray(newsArticles.category, categories),
          eq(newsArticles.language, language)
        )
      )
      .orderBy(desc(newsArticles.publishedAt))
      .limit(limit);

    return await query;
  }

  async createNewsArticle(article: InsertNewsArticle): Promise<NewsArticle> {
    const [created] = await db
      .insert(newsArticles)
      .values(article)
      .returning();
    return created;
  }

  // Consent records operations
  async createConsentRecord(record: InsertConsentRecord): Promise<ConsentRecord> {
    const [created] = await db
      .insert(consentRecords)
      .values(record)
      .returning();
    return created;
  }

  async getUserConsents(userId: string): Promise<ConsentRecord[]> {
    return await db
      .select()
      .from(consentRecords)
      .where(eq(consentRecords.userId, userId))
      .orderBy(desc(consentRecords.createdAt));
  }
}

export const storage = new DatabaseStorage();
