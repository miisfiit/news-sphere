import Parser from 'rss-parser';
import type { Category } from '@shared/schema';

const parser = new Parser();

// RSS feed URLs for different categories
const rssFeedsByCategory: Partial<Record<Category, string[]>> = {
  'World': [
    'https://rss.nytimes.com/services/xml/rss/nyt/World.xml',
    'https://feeds.bbci.co.uk/news/world/rss.xml',
  ],
  'USA': [
    'https://rss.nytimes.com/services/xml/rss/nyt/US.xml',
    'https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml',
  ],
  'Business': [
    'https://rss.nytimes.com/services/xml/rss/nyt/Business.xml',
    'https://feeds.bbci.co.uk/news/business/rss.xml',
  ],
  'Technology': [
    'https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml',
    'https://feeds.bbci.co.uk/news/technology/rss.xml',
  ],
  'Science': [
    'https://rss.nytimes.com/services/xml/rss/nyt/Science.xml',
    'https://feeds.bbci.co.uk/news/science_and_environment/rss.xml',
  ],
  'Sports': [
    'https://rss.nytimes.com/services/xml/rss/nyt/Sports.xml',
    'https://feeds.bbci.co.uk/sport/rss.xml',
  ],
};

// Use fallback generic feed for categories without specific RSS feeds
const genericFeed = 'https://feeds.bbci.co.uk/news/rss.xml';

interface NewsItem {
  title: string;
  description: string;
  content: string;
  category: Category;
  source: string;
  sourceUrl: string;
  imageUrls: string[];
  videoUrl: string | null;
  videoDuration: number | null;
  publishedAt: Date;
  language: string;
  region: string | null;
}

async function fetchRSSFeed(url: string): Promise<any> {
  try {
    const feed = await parser.parseURL(url);
    return feed;
  } catch (error) {
    console.error(`Failed to fetch RSS feed ${url}:`, error);
    return null;
  }
}

function extractImageFromContent(content: string): string | null {
  // Try to extract image URL from HTML content
  const imgRegex = /<img[^>]+src="([^">]+)"/g;
  const match = imgRegex.exec(content);
  return match ? match[1] : null;
}

export async function aggregateNews(categories: Category[], language: string = 'en'): Promise<NewsItem[]> {
  const articles: NewsItem[] = [];

  for (const category of categories) {
    // Get RSS feeds for this category, or use generic feed
    const feeds = rssFeedsByCategory[category] || [genericFeed];
    
    for (const feedUrl of feeds.slice(0, 1)) { // Limit to 1 feed per category for performance
      const feed = await fetchRSSFeed(feedUrl);
      if (!feed || !feed.items) continue;

      // Process up to 3 articles per feed
      for (const item of feed.items.slice(0, 3)) {
        const imageUrl = item.enclosure?.url || item['media:thumbnail']?.['$']?.url || extractImageFromContent(item.content || item['content:encoded'] || '');
        
        const article: NewsItem = {
          title: item.title || 'Untitled',
          description: item.contentSnippet || item.summary || item.description || '',
          content: item.content || item['content:encoded'] || item.description || '',
          category,
          source: feed.title || 'News Source',
          sourceUrl: item.link || '',
          imageUrls: imageUrl ? [imageUrl] : [],
          videoUrl: null, // RSS feeds typically don't include video directly
          videoDuration: null,
          publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
          language,
          region: category.includes('|') ? category.split('|')[1].trim() : null,
        };

        articles.push(article);
      }
    }
  }

  // If no articles were fetched, return mock data as fallback
  if (articles.length === 0) {
    return getMockArticles(categories, language);
  }

  return articles;
}

function getMockArticles(categories: Category[], language: string): NewsItem[] {
  return categories.flatMap((category) => {
    return Array.from({ length: 3 }, (_, i) => ({
      title: `${category} News: Latest Developments ${i + 1}`,
      description: `This is a breaking news story about ${category.toLowerCase()}. Stay informed with the latest updates from our expert journalists.`,
      content: `Full article content about ${category.toLowerCase()} news with detailed information and analysis.`,
      category,
      source: 'News Network',
      sourceUrl: `https://news.example.com/${category.toLowerCase()}-${i + 1}`,
      imageUrls: [`https://picsum.photos/seed/${category}-${i}/800/450`],
      videoUrl: null,
      videoDuration: null,
      publishedAt: new Date(Date.now() - Math.random() * 24 * 60 * 60 * 1000),
      language,
      region: category.includes('|') ? category.split('|')[1].trim() : null,
    }));
  });
}
