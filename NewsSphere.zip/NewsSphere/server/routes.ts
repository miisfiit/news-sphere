import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertUserPreferencesSchema, insertConsentRecordSchema, type Category } from "@shared/schema";
import { aggregateNews } from "./newsAggregator";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User preferences routes
  app.get('/api/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      let prefs = await storage.getUserPreferences(userId);
      
      // Create default preferences if they don't exist
      if (!prefs) {
        prefs = await storage.createUserPreferences({
          userId,
          enabledCategories: ['World', 'USA', 'Business', 'Technology', 'Science', 'Sports'],
          theme: 'system',
          language: 'en',
          fontSize: 'medium',
          voiceEnabled: false,
          locationConsent: false,
        });
      }
      
      res.json(prefs);
    } catch (error) {
      console.error("Error fetching preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.put('/api/preferences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Validate request body
      const updates = insertUserPreferencesSchema.partial().parse(req.body);
      
      // Get existing preferences or create default
      let prefs = await storage.getUserPreferences(userId);
      if (!prefs) {
        prefs = await storage.createUserPreferences({
          userId,
          enabledCategories: ['World', 'USA', 'Business', 'Technology', 'Science', 'Sports'],
          theme: 'system',
          language: 'en',
          fontSize: 'medium',
          voiceEnabled: false,
          locationConsent: false,
        });
      }
      
      // Update preferences
      const updated = await storage.updateUserPreferences(userId, updates);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      console.error("Error updating preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  // News routes
  app.get('/api/news', async (req, res) => {
    try {
      const categoriesParam = req.query.categories as string | undefined;
      const language = (req.query.language as string) || 'en';
      
      // Parse categories from query or use defaults
      let categories: Category[] = ['World', 'USA', 'Business', 'Technology', 'Science', 'Sports'];
      if (categoriesParam) {
        try {
          categories = JSON.parse(categoriesParam);
        } catch {
          categories = categoriesParam.split(',') as Category[];
        }
      }
      
      // For authenticated users, use their preferences
      if (req.isAuthenticated && (req as any).user?.claims?.sub) {
        const userId = (req as any).user.claims.sub;
        const prefs = await storage.getUserPreferences(userId);
        if (prefs) {
          categories = prefs.enabledCategories;
        }
      }
      
      // Try to get recent articles from database first
      let articles = await storage.getNewsArticles(categories, language, 50);
      
      // If no articles in database or articles are old, fetch fresh content
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const needsRefresh = articles.length === 0 || 
        (articles[0]?.createdAt && new Date(articles[0].createdAt) < oneHourAgo);
      
      if (needsRefresh) {
        console.log('Fetching fresh news articles...');
        const aggregatedArticles = await aggregateNews(categories, language);
        
        // Store aggregated articles in database
        for (const article of aggregatedArticles) {
          try {
            await storage.createNewsArticle(article);
          } catch (error) {
            // Ignore errors (article might already exist)
          }
        }
        
        // Fetch the newly stored articles
        articles = await storage.getNewsArticles(categories, language, 50);
      }
      
      res.json(articles);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ message: "Failed to fetch news" });
    }
  });

  // Consent management routes - accessible to all users for compliance
  app.post('/api/consent', async (req: any, res) => {
    try {
      // Get user ID if authenticated, otherwise null (for unauthenticated cookie consent)
      const userId = req.isAuthenticated && req.user?.claims?.sub ? req.user.claims.sub : null;
      const ipAddress = req.ip || req.connection.remoteAddress;
      
      // Validate request body
      const consentData = insertConsentRecordSchema.parse({
        ...req.body,
        userId,
        ipAddress,
      });
      
      const record = await storage.createConsentRecord(consentData);
      res.json(record);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request data", errors: error.errors });
      }
      console.error("Error creating consent record:", error);
      res.status(500).json({ message: "Failed to create consent record" });
    }
  });

  app.get('/api/consent', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const records = await storage.getUserConsents(userId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching consent records:", error);
      res.status(500).json({ message: "Failed to fetch consent records" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
